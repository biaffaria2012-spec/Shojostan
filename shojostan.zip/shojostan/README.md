# SHOJOSTAN ✦

Site estático em pt-BR com estética cute/dark inspirada em Jujutsu Kaisen, pronto para testar no GitHub Pages.

## O que já está incluído
- Página inicial, lista de jogos e quizzes, notícias e ranking.
- Catálogo com 50 conceitos de jogos e 50 quizzes.
- Protótipos jogáveis para memória, toque, reflexo, sequência, corrida/flappy, labirinto, duelo e outros.
- Painel de administração de demonstração para publicar/retirar jogos e quizzes.
- Formulário de notícias com nome do autor, título, conteúdo, fixar, editar e excluir.
- Ranking local e exportação de backup JSON.
- Interface responsiva e pt-BR.

## Importante antes de publicar
**O painel atual é uma demonstração local.** A senha `malvaviolet` está no JavaScript e não é segura. Os dados e rankings ficam no `localStorage` do navegador e não são compartilhados entre visitantes. Não use este login para proteger notícias ou conteúdo real em um site público.

Para ter autenticação real, notícias compartilhadas e rankings globais:
1. Crie um projeto Supabase.
2. Configure Supabase Auth para seu usuário administrador.
3. Crie tabelas para `catalog_items`, `news_posts` e `scores`.
4. Ative Row Level Security (RLS) e escreva políticas que permitam leitura pública apenas para itens publicados; somente o usuário administrador pode inserir, editar, publicar ou excluir itens/notícias.
5. Valide pontuações no servidor sempre que possível para reduzir fraudes.
6. Integre o cliente Supabase ao frontend usando apenas a chave pública/anon (nunca exponha service-role key).

O protótipo é intencionalmente independente de Supabase para que você consiga testar a interface logo de início.

## Publicar no GitHub Pages
1. Baixe e extraia `shojostan.zip`.
2. Crie um repositório no GitHub, por exemplo `shojostan`.
3. Envie `index.html` e `README.md` para a raiz do repositório (não deixe como `index (1).html`).
4. No repositório, abra **Settings → Pages**.
5. Em **Build and deployment**, selecione **Deploy from a branch**, escolha `main` e `/ (root)` e salve.
6. Aguarde a publicação. O link será parecido com `https://SEU-USUARIO.github.io/shojostan/`.

## Como testar
- Abra o site e explore Jogos, Quizzes, Rankings e Notícias.
- Clique em Administração e use a senha de demonstração `malvaviolet`.
- No catálogo, clique em Publicar/Retirar.
- Em Notícias, publique uma notícia com o nome que quiser.
- As mudanças ficam apenas nesse navegador; limpe cache/dados do site com cuidado, pois isso pode apagar o estado local.

## Notas
- Os jogos com mecânicas completas no protótipo são versões simples para demonstrar o fluxo. Alguns itens do catálogo usam protótipos genéricos e podem ser ampliados.
- SHojostan é um fan project não oficial. Jujutsu Kaisen e seus personagens pertencem aos respectivos titulares.
